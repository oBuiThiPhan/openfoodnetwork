(function() {
  angular.module("admin.orders", ['admin.indexUtils', 'ngResource']);

}).call(this);

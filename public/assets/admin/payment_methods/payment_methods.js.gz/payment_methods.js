(function() {
  angular.module("admin.paymentMethods", ['ngTagsInput', 'admin.utils', 'templates']);

}).call(this);

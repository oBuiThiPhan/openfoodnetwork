(function() {
  angular.module("admin.side_menu", []);

}).call(this);

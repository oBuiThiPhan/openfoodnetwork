(function() {
  angular.module("admin.businessModelConfiguration", ["admin.utils"]);

}).call(this);

(function() {
  angular.module("admin.enterprise_groups", ["admin.side_menu", "admin.users", "textAngular"]);

}).call(this);

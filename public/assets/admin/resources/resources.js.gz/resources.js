(function() {
  angular.module("admin.resources", ['ngResource']);

}).call(this);

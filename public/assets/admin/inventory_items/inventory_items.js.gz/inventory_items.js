(function() {
  angular.module("admin.inventoryItems", ['ngResource']);

}).call(this);

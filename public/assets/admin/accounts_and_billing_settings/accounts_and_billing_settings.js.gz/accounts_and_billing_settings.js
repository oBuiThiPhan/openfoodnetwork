(function() {
  angular.module("admin.accounts_and_billing_settings", ["admin.utils"]);

}).call(this);

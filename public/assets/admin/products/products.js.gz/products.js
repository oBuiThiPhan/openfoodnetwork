(function() {
  angular.module("admin.products", ["textAngular", "admin.utils"]);

}).call(this);

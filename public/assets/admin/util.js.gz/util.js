$(document).ready(function() {
  $('.datetimepicker').datetimepicker({
    dateFormat: Spree.translations.date_picker,
    dayNames: Spree.translations.abbr_day_names,
    dayNamesMin: Spree.translations.abbr_day_names,
    monthNames: Spree.translations.month_names,
    prevText: Spree.translations.previous,
    nextText: Spree.translations.next,
    showOn: "button",
    buttonImage: "/assets/datepicker/cal.gif",
    buttonImageOnly: true,
    stepMinute: 15
  });
});

// Overriding a broken function in Spree. Bug report at
// https://github.com/spree/spree/issues/4032
show_flash_error = function(message) {
  error_div = $('.flash.error');
  if (error_div.length > 0) {
    error_div.html(message);
    error_div.show();
  } else {
    if ($("#content .toolbar").length > 0) {
      $("#content .toolbar").before('<div class="flash error">' + message + '</div>');
    } else {
      $("#progress").before('<div class="flash error">' + message + '</div>');
    }
  }
}

$(document).ready(function(){
  $('a.close').click(function(event){
    event.preventDefault();
    $(this).parent().slideUp(250);
  });

  // Spree locates hidden with prev(), which with our current version of jQuery
  // does not locate the hidden field, resulting in the delete failing. This
  // handler updates the hidden field, fixing the problem.
  $('body').on('click', 'a.remove_fields', function() {
    $(this).next("input[type=hidden]").val("1");
    return false;
  });
});

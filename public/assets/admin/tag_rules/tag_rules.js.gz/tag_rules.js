(function() {
  angular.module("admin.tagRules", ['ngResource', 'ngTagsInput']);

}).call(this);

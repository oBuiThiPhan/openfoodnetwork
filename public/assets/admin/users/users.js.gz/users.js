(function() {
  angular.module("admin.users", ['admin.utils']);

}).call(this);

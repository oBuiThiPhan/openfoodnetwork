(function() {
  angular.module("admin.utils", ["templates", "ngSanitize"]);

}).call(this);

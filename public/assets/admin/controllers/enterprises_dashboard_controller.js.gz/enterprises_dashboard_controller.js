(function() {
  angular.module("ofn.admin").controller("enterprisesDashboardCtrl", function($scope) {
    return $scope.activeTab = "hubs";
  });

}).call(this);

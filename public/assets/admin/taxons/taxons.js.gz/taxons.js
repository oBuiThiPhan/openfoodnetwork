(function() {
  angular.module("admin.taxons", ['ngSanitize']);

}).call(this);

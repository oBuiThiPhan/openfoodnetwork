(function() {
  angular.module("admin.dropdown", ['templates']);

}).call(this);
